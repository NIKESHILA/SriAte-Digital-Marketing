function scheduleCall() {
    // Add functionality for scheduling a call
    alert("Schedule a call feature coming soon!");
}
